---
title: Check2 square
categories:
  - UI and keyboard
tags:
  - checkmark
  - todo
  - select
  - done
  - checkbox
---
